# GeStockCI

PWA de gestion de stock, caisse et crédits clients pour boutiques et marchands
(formel et informel) en Côte d'Ivoire — français / anglais, avec un espace
administrateur séparé pour créer les comptes et suivre les abonnements.

## Structure du projet

```
gestockci/
  public/
    app/        → application utilisateur (PWA, hébergée sur GitHub Pages)
    admin/       → espace administrateur (même hébergement, dossier séparé)
  functions/     → Cloud Functions Firebase (création de comptes, admin)
  firestore.rules
```

## 1. Créer le projet Firebase (gratuit, plan Spark)

1. Va sur https://console.firebase.google.com → **Ajouter un projet**.
2. Active **Authentication** → méthode **Email/Mot de passe**.
3. Active **Firestore Database** (mode production).
4. Dans **Paramètres du projet → Vos applications**, ajoute une application
   web et copie la configuration dans :
   `public/app/js/config.js` (le même fichier est réutilisé par `public/admin/`).

## 2. Installer les outils Firebase

```bash
npm install -g firebase-tools
firebase login
cd gestockci
firebase init
# Sélectionne : Firestore, Functions, Hosting (facultatif si tu restes sur GitHub Pages)
```

## 3. Déployer les règles et les fonctions

```bash
firebase deploy --only firestore:rules
cd functions && npm install && cd ..
firebase deploy --only functions
```

## 4. Créer le tout premier administrateur (toi)

1. Dans la console Firebase → Authentication, crée manuellement un compte
   avec ton email et un mot de passe.
2. Connecte-toi une fois sur `public/admin/login.html` en local (il te
   redirigera vers `login.html` car tu n'es pas encore admin — c'est normal).
3. Depuis la console du navigateur (F12), appelle une fois la fonction
   `promouvoirAdmin` pour transformer ce compte en administrateur, ou fais-le
   directement depuis la console Firebase en ajoutant un document dans la
   collection `admins` avec pour ID ton `uid` Firebase Auth.
4. Ensuite, reconnecte-toi normalement sur `public/admin/login.html` — tu
   accèdes au tableau de bord admin et peux créer tous les comptes utilisateurs
   depuis **Utilisateurs → Nouvel utilisateur**.

## 5. Déployer le front sur GitHub Pages

```bash
git init
git add .
git commit -m "GeStockCI — première version"
git branch -M main
git remote add origin https://github.com/<ton-compte>/gestockci.git
git push -u origin main
```

Dans **Settings → Pages** du dépôt GitHub, choisis la branche `main` et le
dossier `/public`. L'app utilisateur sera accessible sur
`https://<ton-compte>.github.io/gestockci/app/login.html` et l'admin sur
`https://<ton-compte>.github.io/gestockci/admin/login.html`.

## Point d'honnêteté technique — rappels par SMS

Un envoi de **SMS automatique** dans un délai raisonnable nécessite un
service payant (Twilio, Orange SMS API, etc.) — aucune solution gratuite
fiable n'existe pour la Côte d'Ivoire. Pour rester 100 % gratuit dans cette
première version, les relances de créances se font via un **lien WhatsApp
pré-rempli** (bouton "Relancer" dans Le Carnet) : le message est déjà rédigé,
il suffit d'appuyer sur Envoyer. C'est gratuit, fonctionne dès aujourd'hui, et
correspond à un usage déjà très répandu chez les commerçants ivoiriens.

Si tu veux plus tard de vrais SMS automatiques programmés (sans WhatsApp
installé côté client), il faudra brancher un compte Twilio ou un fournisseur
SMS local dans une Cloud Function dédiée — dis-le-moi et je l'ajoute.

## Icônes

Les icônes fournies (`public/app/icons/`) sont un simple espace réservé
(logo "GS"). Remplace-les par ton propre logo avant la mise en production.

## Ce qui est fonctionnel dans cette version

- Connexion utilisateur (compte créé uniquement par l'admin)
- Tableau de bord avec KPIs (CA du jour, bénéfice estimé, dettes, ruptures) et
  graphique des 7 derniers jours
- Gestion des produits (ajout, modification, alerte de seuil)
- Caisse : panier, règlement espèces / Mobile Money / crédit, mise à jour
  automatique du stock
- Le Carnet : clients à crédit, solde dû, relance WhatsApp pré-rédigée
- Mode hors-ligne (cache Firestore + service worker pour l'App Shell)
- Français / anglais avec bascule instantanée
- Espace administrateur séparé : création de comptes, tableau de bord des
  abonnements (mensuel/annuel, actifs/expirés)

## À construire ensuite (fonctionnalités secondaires)

- Export PDF des inventaires (la structure des données est prête ; il reste
  à brancher une librairie comme jsPDF côté client)
- Scan de code-barres pour la caisse
- Reçu numérique détaillé partageable par WhatsApp
- Gestion fine des abonnements expirés (blocage automatique de l'accès)
